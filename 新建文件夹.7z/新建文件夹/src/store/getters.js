//一个包含n个基于state计算getter属性的方法的对象

export default {
  
}
