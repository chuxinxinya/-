//定义常量的模块

export const RECEIVE_ADDRESS = 'receive_address'

export const RECEIVE_CATEGORYS = 'receive_categorys'

export const RECEIVE_SHOPS = 'receive_shops'